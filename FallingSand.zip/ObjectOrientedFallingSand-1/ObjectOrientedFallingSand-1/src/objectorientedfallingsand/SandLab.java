package objectorientedfallingsand;

import java.awt.*;
import java.util.Arrays;

public class SandLab
{
    //do not add any more fields
    private Particle[][] grid;
    private SandDisplay display;
    public static final int ROWS = 120;
    public static final int COLUMNS = 80;


    public static void main(String[] args)
    {
        SandLab lab = new SandLab(ROWS, COLUMNS);
        lab.run();
    }

    public SandLab(int numRows, int numCols)
    {
        Movement left = new Movement(0, -1);
        Movement down = new Movement(1, 0);
        Movement right = new Movement(0, 1);
        Movement up = new Movement(-1, 0);
        Movement none = new Movement(0, 0);
        
        Particle empty = new Particle();
        empty.setColor(Color.black);
        empty.setName("empty");
        
        Particle metal = new Particle();
        metal.setColor(Color.DARK_GRAY);
        metal.setName("metal");
        
        
        Particle sand = new Particle();
        sand.setColor(Color.yellow);
        sand.setName("sand");
        sand.addMovement(down);
        
        Particle water = new Particle();
        water.setColor(Color.blue);
        water.setName("water");
        water.addMovement(left);
        water.addMovement(down);
        water.addMovement(right);
        
        Particle acid = new Particle();
        acid.setColor(Color.cyan);
        acid.setName("acid");
        acid.addMovement(left);
        acid.addMovement(down);
        acid.addMovement(right);
        
        
        
        Particle lava = new Particle();
        lava.setColor(Color.red);
        lava.setName("lava");
        lava.addMovement(left);
        lava.addMovement(right);
        lava.addMovement(down);   
        
        Particle seed = new Particle();
        seed.setColor(new Color(38, 54, 24));
        seed.setName("seed");
        seed.addMovement(down);
        
        Particle wood = new Particle();
        wood.setColor(new Color(51, 0, 0));
        wood.setName("wood");
        wood.addMovement(up);
        wood.addMovement(left);
        wood.addMovement(right);
        
        Particle leaf = new Particle();
        leaf.setColor(Color.green);
        
        Particle dirt = new Particle();
        dirt.setColor(new Color(153, 102, 0));
        dirt.setName("dirt");
        dirt.addMovement(down);
        
        Algae algae = new Algae();
        algae.addMovement(down);
        
        Particle stone = new Particle();
        stone.setColor(Color.GRAY);
        stone.setName("stone");
        
        Aging aging = new Aging();       
        aging.setName("aging");
        aging.addMovement(left);
        aging.addMovement(right);
        aging.addMovement(up);
        aging.addMovement(up);
        aging.addMovement(up);
        aging.addMovement(up);
        
        
        
        
        
        
      Particle[] particlesUnsorted = new Particle[8];
        
        particlesUnsorted[0] = metal;
        particlesUnsorted[1] = sand;
        particlesUnsorted[2] = water;
        particlesUnsorted[3] = acid;
        particlesUnsorted[4] = lava;
        particlesUnsorted[5] = seed;
        particlesUnsorted[6] = dirt;
        particlesUnsorted[7] = aging;
        
        Arrays.sort(particlesUnsorted);
        
        Particle[] particles = new Particle[9];
        //Kept empty at the top
        particles[0] = empty;
        particles[1] = particlesUnsorted[0];
        particles[2] = particlesUnsorted[1];
        particles[3] = particlesUnsorted[2];
        particles[4] = particlesUnsorted[3];
        particles[5] = particlesUnsorted[4];
        particles[6] = particlesUnsorted[5];
        particles[7] = particlesUnsorted[6];
        particles[8] = particlesUnsorted[7];
        
        
        
        
        
        
        display = new SandDisplay("Falling Sand", numRows, numCols, particles);
        grid = new Particle[numRows][numCols];
        
        Relationship sandWithEmpty = new Relationship(empty, empty, sand);
        sand.addRelationship(sandWithEmpty);
        sand.addRelationship(new Relationship(water, water, sand));
        sand.addRelationship(new Relationship(acid, acid, sand));
        sand.addRelationship(new Relationship(lava, aging, empty));
        sand.addRelationship(new Relationship(algae, water, sand));
        
        water.addRelationship(new Relationship(empty, empty, water));
        water.addRelationship(new Relationship(sand, algae, sand));
        water.addRelationship(new Relationship(lava, lava, aging));
        acid.addRelationship(new Relationship(empty, empty, acid));
        acid.addRelationship(new Relationship(metal, aging, aging));
        
        aging.addRelationship(new Relationship(empty, empty, aging));
        aging.addRelationship(new Relationship(aging, aging, empty));
        aging.addRelationship(new Relationship(lava, lava, empty));
        
        lava.addRelationship(new Relationship(empty, aging, lava));
        lava.addRelationship(new Relationship(water, stone, lava));
        lava.addRelationship(new Relationship(sand, aging, empty));
        lava.addRelationship(new Relationship(acid, lava, aging));
        lava.addRelationship(new Relationship(algae, aging, empty));
        lava.addRelationship(new Relationship(wood, aging, aging));
        lava.addRelationship(new Relationship(leaf, aging, aging));
        lava.addRelationship(new Relationship(dirt, aging, aging));
        
        
        seed.addRelationship(new Relationship(empty, empty, seed));
        seed.addRelationship(new Relationship(dirt, empty, wood));
        seed.addRelationship(new Relationship(seed, empty, empty));
        seed.addRelationship(new Relationship(leaf, empty, empty));
        
        wood.addRelationship(new Relationship(empty, wood, leaf));
        
        leaf.addRelationship(new Relationship(empty, leaf, leaf));
        
        dirt.addRelationship(new Relationship(empty, empty, dirt));
        dirt.addRelationship(new Relationship(acid, acid, dirt));
        dirt.addRelationship(new Relationship(lava, aging, empty));
        dirt.addRelationship(new Relationship(water, water, dirt));
        
        algae.addRelationship(new Relationship(algae, water, water));
        algae.addRelationship(new Relationship(water, water, algae));
        algae.addRelationship(new Relationship(empty, empty, algae));
        
       
        
        
        
        
        
        
        
        
       
        
        for(int i = 0; i <= numRows - 1; i++){
            for(int j = 0; j <= numCols - 1; j++){   
            grid[i][j] = particles[0];
            }
        }
        
        
        

    }

    //called when the user clicks on a location using the given tool
    private void locationClicked(int row, int col, Particle tool)
    {
        
        Particle particle;
        particle = grid[row][col];
        
        grid[row][col] = particle.clone(tool);
        
        
    }

    //copies each element of grid into the display
    public void updateDisplay()
    {
        Particle particle;
        
        for (int row = 0; row < ROWS; row++)
        {
            for (int column = 0; column < COLUMNS; column++)
            {
                particle = grid[row][column];
                display.setColor(row, column, particle.getColor());
            }
        }
    }

    //called repeatedly.
    //causes one random particle to maybe do something.
    public void step()
    {
        int row = (int)(Math.random() * ROWS);
        int column = (int)(Math.random() * COLUMNS); 
        Particle particle = grid[row][column];        
        
        
        if(particle.isMoveable()){
            
            Movement movement = particle.getRandomMovement();

            if(movement.getColumnChange() + column < COLUMNS && movement.getColumnChange() + column >= 0 && movement.getRowChange() + row < ROWS && movement.getRowChange() + row >= 0){
                Particle particle2 = grid[row + movement.getRowChange()][column + movement.getColumnChange()];
                if(particle.hasRelationshipWith(particle2)){
                    Relationship relationship = particle.getRelationshipWith(particle2);
                    grid[row + movement.getRowChange()][column + movement.getColumnChange()] = relationship.getNewSecondParticle();
                    grid[row][column]= relationship.getNewFirstParticle();
                }
              
            }
            
        }
        
        
    }

    //do not modify
    public void run()
    {
        while (true)
        {
            for (int i = 0; i < display.getSpeed(); i++)
            {
                step();
            }

            updateDisplay();
            display.repaint();
            display.pause(1);  //wait for redrawing and for mouse
            int[] mouseLoc = display.getMouseLocation();

            if (mouseLoc != null)  //test if mouse clicked
            {
                locationClicked(mouseLoc[0], mouseLoc[1], display.getTool());
            }
        }
    }
}