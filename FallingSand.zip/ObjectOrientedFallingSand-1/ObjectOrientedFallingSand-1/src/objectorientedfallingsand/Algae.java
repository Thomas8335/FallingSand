
package objectorientedfallingsand;

import java.awt.Color;
import java.util.ArrayList;


public class Algae extends Particle{
   
    private ArrayList<Movement> movements;
    
    public Algae(){
        this.setColor(Color.pink);
        this.setName("algae");
        
        
    }

    
}
