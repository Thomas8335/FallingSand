package objectorientedfallingsand;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
public class Particle implements Comparable<Particle>
{
    // Fields go here.
    private String name;
    private Color color;
    private ArrayList<Movement> movements;
    private ArrayList<Relationship>relationships;
    
    
    
    // Constructor(s) go here.
    public Particle(){
        name = "";
        color = Color.white;
        movements = new ArrayList<Movement>();
        relationships = new ArrayList<Relationship>();
        
        
    }
    // Methods go here.
    public void setName(String inName){
        name = inName;
    }
    public String getName()
    {
        return name;
    }
    
    public void setColor(Color inColor){
        color = inColor;
    }
    
    public Color getColor(){
        return color;
    }
    
  
    
    
    public Particle clone(Particle particle){
        Particle cloneParticle = new Particle();
        cloneParticle.setColor(particle.getColor());
        cloneParticle.setName(particle.getName());
        cloneParticle.movements = particle.movements;
        cloneParticle.relationships = particle.relationships;
        return cloneParticle;
    }
    
    public void addMovement(Movement movement){
        movements.add(movement);
    }
    
    
    public boolean isMoveable(){
        if(movements.size() > 0){
            return true;
        }else{
            return false;
        }
    }
    
    public Movement getRandomMovement(){
        if(movements.size() == 0){
            return new Movement(0, 0);
        }else if(name.equals("sand") || name.equals("seed") || name.equals("wood") || name.equals("leaf") || name.equals("algae") || name.equals("dirt") || name.equals("stone")){
            return movements.get(0);
        }
        
        else{    
            Random random = new Random();
            int randomNum = random.nextInt(2 - 0 + 1) + 0;
            return movements.get(randomNum);
        }
        
    }
    
    public void addRelationship(Relationship relationship){
        relationships.add(relationship);
    }
    
        public ArrayList<Movement> getMovements(){
        return movements;
    }
    
    public void setMovements(ArrayList <Movement> inMovements){
        movements = inMovements;
    }
    
    public ArrayList<Relationship> getRelationships(){
        return relationships;
    }
    
    public void setRelationships(ArrayList <Relationship> inRelationships){
        relationships = inRelationships;
    }
    
    @Override
    public boolean equals(Object other){
        Particle particle = (Particle) other;
        if(particle.getName().equals(this.getName())){
            return true;
        }else{
            return false;
        }
    }

    public boolean hasRelationshipWith(Particle otherParticle){
        
        ArrayList<Relationship> relationships2 = this.relationships;
        for(int i = 0; i < relationships2.size(); i++){
            if(otherParticle.equals(relationships2.get(i).getOtherParticle())){
                return true;
            }
        }
        return false;
        
    }
    
    public Relationship getRelationshipWith(Particle otherParticle){
        
        ArrayList<Relationship> relationships2 = this.relationships;
        for(int i = 0; i < relationships2.size(); i++){
            if(otherParticle.equals(relationships2.get(i).getOtherParticle())){
                return relationships2.get(i);
                
            }
        }
        return null;
    }
    
    
    
    @Override
    public int compareTo(Particle inParticle){
        int value = 0;
        
        if(this.name.charAt(0) > inParticle.name.charAt(0)){
            value = 1;
        }else{
            value = -1;
        }
        
        return value;
    }
    
 
    

}
