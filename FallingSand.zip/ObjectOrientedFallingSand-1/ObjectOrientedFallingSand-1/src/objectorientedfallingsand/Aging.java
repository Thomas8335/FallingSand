
package objectorientedfallingsand;

import java.awt.Color;
import java.util.ArrayList;


public class Aging extends Particle{
    
    private int health;
    private ArrayList<Color> colors;
    
    public Aging(){
        health = 500;
        colors = new ArrayList<Color>();
        colors.add(new Color(51, 51, 51));
        colors.add(new Color(102, 102, 102));            
        colors.add(new Color(153, 153, 153));          
        colors.add(new Color(204, 204, 204));
    }
    
    
    
    @Override
    public Particle clone(Particle particle){
        Particle cloneParticle = new Aging();
        cloneParticle.setColor(particle.getColor());
        cloneParticle.setName(particle.getName());
        cloneParticle.setMovements(particle.getMovements());
        cloneParticle.setRelationships(particle.getRelationships());
        
        return cloneParticle;
    }
    
    @Override
    public boolean isMoveable(){
        
        if(health > 0){
            health--;
        }
        if(this.getMovements().size() > 0){
           
            return true;
            
        }else{ 
            
            return false;
        }
        
    }
    
    @Override
    public Color getColor(){
        Color color;

            if(health >= 400){
                color = colors.get(3);
            }else if(health >= 300){
                color = colors.get(2);
            }else if(health >= 100){
                color = colors.get(1);
            }else if(health >= 1){
                color = colors.get(0);
            }else{
                color = new Color(0, 0, 0);
            }
            
            
        return color;
    }
    
    

    
    
    
    
}
