package objectorientedfallingsand;

public class Relationship {
    
    private Particle otherParticle;
    private Particle newFirstParticle;
    private Particle newSecondParticle;
    
    public Relationship(Particle inOtherParticle, Particle inNewFirstParticle, Particle inNewSecondParticle){
        otherParticle = inOtherParticle;
        newFirstParticle = inNewFirstParticle;
        newSecondParticle = inNewSecondParticle;
    }
    
    public Particle getOtherParticle(){
        return otherParticle.clone(otherParticle);
    }
    
    public Particle getNewFirstParticle(){
        return newFirstParticle.clone(newFirstParticle);
    }
    
    public Particle getNewSecondParticle(){
        return newSecondParticle.clone(newSecondParticle);
    }
    
    
    
}
